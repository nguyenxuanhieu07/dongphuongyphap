<?php

require_once (__DIR__) . '/simple-link-list/simple-link-list-widget.php';

/**
 * require widget form 
 */
require_once (__DIR__) . '/widget-heal-1.php';

/**
 * require widget form 
 */
require_once (__DIR__) . '/widget-heal-2.php';

/**
 * require widget form 
 */
require_once (__DIR__) . '/widget-target-link.php';