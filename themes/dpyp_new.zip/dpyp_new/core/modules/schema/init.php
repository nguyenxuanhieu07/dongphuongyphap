<?php 
require_once (__DIR__) . "/homepage.php";

require_once (__DIR__) . "/page.php";

require_once (__DIR__) . "/post.php";