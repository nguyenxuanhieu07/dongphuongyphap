<?php 
/**
 * Theme initialization
 */
require_once (__DIR__) . '/create-post-type-doctor.php';
/**
 * Video Metabox
 */
require_once (__DIR__) . '/metabox.php';