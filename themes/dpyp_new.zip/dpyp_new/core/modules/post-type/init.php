<?php
/**
 * testinomial 
 */
 require (__DIR__) . '/testinomial/init.php';
/**
 * Video 
 */
require(__DIR__) . '/video/init.php';
/**
 * faq 
 */
 require (__DIR__) . '/faq/init.php';

/**
 * doctor 
 */
require(__DIR__) . '/doctor/init.php';

/**
 * post
 */
require(__DIR__) . '/post/init.php';

/**
 * Post type Hệ giải pháp điều trị
 */
require(__DIR__) . '/solution/init.php';
/**
 * Post type bệnh điều trị
 */
require(__DIR__) . '/disease/init.php';
/**
 * Post type huyệt đạo
 */
require(__DIR__) . '/acupoints/init.php';
/**
 * products
 */
require(__DIR__) . '/products/init.php';