<?php 
/**
 * Theme initialization
 */
require_once (__DIR__) . '/create-post-type-video.php';
/**
 * Video Metabox
 */
require_once (__DIR__) . '/metabox.php';