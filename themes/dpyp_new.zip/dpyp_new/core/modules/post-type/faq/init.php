<?php 
/**
 * Theme initialization
 */
require_once (__DIR__) . '/create-post-type-faq.php';