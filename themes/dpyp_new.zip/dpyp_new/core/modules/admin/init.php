<?php 
require_once dirname(__FILE__). '/dashboard.php';
require_once dirname(__FILE__). '/editor-style.php';
require_once dirname(__FILE__). '/link-no-follow.php';
require_once dirname(__FILE__). '/limit-image-size.php';
require_once dirname(__FILE__). '/duplicate-post-type.php';