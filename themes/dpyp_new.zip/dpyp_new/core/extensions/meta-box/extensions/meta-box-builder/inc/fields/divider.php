<p class="link-to-original">
	No option for divider.
</p>