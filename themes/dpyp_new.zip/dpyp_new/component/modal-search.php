<div class="modal fade modal-search" id="modal-search" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="modal-searchLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modal-searchLabel">Tìm kiếm</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="/" method="GET" class="search-form">
					<div class="form-group">
						<input type="text" name="s" class="form-control" placeholder="Từ khóa tìm kiếm">
						<button type="submit" class="btn btn-search d-flex align-items-center" aria-label="Search">
							<span class="icon-search fa fa-search"></span>
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>